# mathisgreate4

A neon-themed static website for GitHub Pages.

## Publish with GitHub Pages

1. In your GitHub repository, choose **Add file → Upload files**.
2. Upload `index.html` from this folder (and optionally this README).
3. Commit the changes to the `main` branch.
4. Open **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Choose branch **main** and folder **/(root)**, then click **Save**.
7. Wait a minute or two. GitHub will show the published site URL on the Pages screen.

If your repository is named `mathisgreate4`, the URL will usually be:
`https://YOUR-GITHUB-USERNAME.github.io/mathisgreate4/`

If you keep the existing repository name `school.site`, the URL will use that name instead:
`https://YOUR-GITHUB-USERNAME.github.io/school.site/`

To change the repository name, open **Settings → General → Repository name**, enter `mathisgreate4`, and click **Rename**.

Note: GitHub Pages hosts the site; it does not bypass school network filters. External sites may be blocked by the network or by their own access rules.
